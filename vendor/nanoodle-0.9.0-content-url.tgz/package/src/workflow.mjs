import { NanoodleError, RunError, UnsupportedNodeError } from "./errors.mjs";
import { NODE_TYPES, displayName, isInputPort, lockedNode, materialize, topoSort, wiredFramesFloor, MAX_FRAMES } from "./graph.mjs";
import { endpointOutPort } from "./endpoint.mjs";
import { deriveInputs, deriveOutputs, deriveSettings, resolveInputKey, resolveSettingKey } from "./io.mjs";
import { NanoClient } from "./client.mjs";
import { MediaRef, coerceMediaInput } from "./media.mjs";
import { RUNNERS } from "./nodes.mjs";
import { learnPromptCap, withFittedPrompt } from "./prompt-caps.mjs";
import { decodeShareUrl, isShareRef } from "./share.mjs";

/** Env / process access — safe when `process` is missing (browsers, some workers). */
function envApiKey() {
  try {
    return typeof process !== "undefined" && process.env ? process.env.NANOGPT_API_KEY : undefined;
  } catch {
    return undefined;
  }
}

function warnGraph(msg) {
  try {
    if (typeof process !== "undefined" && typeof process.emitWarning === "function") {
      process.emitWarning(msg, { code: "NANOODLE_GRAPH" });
      return;
    }
  } catch { /* ignore */ }
  if (typeof console !== "undefined" && console.warn) console.warn("[nanoodle]", msg);
}

const MEDIA_KINDS = new Set(["image", "audio", "video", "inpaint"]);
/** Ports whose value is media a later node will fetch or inline. */
const HANDED_MEDIA_PORT = /^(?:video|audio|image|mask|endframe|model)$|^(?:img|image|vid|clip|ref|frame)\d+$/;
const MEDIA_OUT_TYPES = new Set(["image", "audio", "video", "model3d"]);

function mediaOutputKeys(node, out) {
  const keys = [];
  const add = (k) => { if (k && !keys.includes(k)) keys.push(k); };
  if (!out || typeof out !== "object") return keys;
  if (node.type === "endpoint") {
    const p = endpointOutPort(node);
    if (p && MEDIA_OUT_TYPES.has(p.type)) add(p.name);
  } else if (node.type === "vframes") {
    for (const k of Object.keys(out)) if (/^frame\d+$/.test(k)) add(k);
  } else {
    const spec = NODE_TYPES[node.type];
    for (const p of (spec && spec.outputs) || []) {
      if (MEDIA_OUT_TYPES.has(p.type)) add(p.name);
    }
  }
  if (Array.isArray(out.images)) add("images");
  return keys;
}

/**
 * Resolve provider-relative content URLs on a node's media outputs before they
 * are stored or wired onward. One fetch per distinct URL (image + images[]).
 */
async function publishNodeMedia(client, node, out, signal) {
  if (!out || typeof out !== "object" || Array.isArray(out)) return out;
  const keys = mediaOutputKeys(node, out);
  if (!keys.length) return out;
  const cache = new Map();
  const resolve = async (value) => {
    if (typeof value === "string") {
      if (!value) return value;
      if (cache.has(value)) return cache.get(value);
      const resolved = await client.resolveContentUrl(value, { signal });
      cache.set(value, resolved);
      return resolved;
    }
    if (Array.isArray(value)) {
      let changed = false;
      const next = [];
      for (const item of value) {
        const r = await resolve(item);
        if (r !== item) changed = true;
        next.push(r);
      }
      return changed ? next : value;
    }
    return value;
  };
  let copy = null;
  for (const k of keys) {
    const resolved = await resolve(out[k]);
    if (resolved !== out[k]) {
      if (!copy) copy = { ...out };
      copy[k] = resolved;
    }
  }
  return copy || out;
}

function abortReason(signal) {
  const r = signal && signal.reason;
  if (r instanceof Error) return r;
  return new NanoodleError(r != null ? String(r) : "run aborted", { code: "aborted" });
}

function throwIfAborted(signal) {
  if (signal && signal.aborted) throw abortReason(signal);
}

/** The outcome of Workflow.run(). Media values are MediaRef; text values plain strings. */
/** Internal: thrown by a node skipped behind a closed gate, so ITS dependents skip too. Never surfaced. */
class GateSkip extends Error {
  constructor(gatedBy) { super("skipped — a gate upstream said no"); this.gatedBy = gatedBy; }
}

export class RunResult {
  constructor({ outputs, nodes, errors, gated = [], costUsd, costExact, remainingBalance }) {
    /** { [friendlyKey | nodeId]: value } — sink node primary outputs (a sink skipped by a closed gate has none) */
    this.outputs = outputs;
    /**
     * per-node { status: "done"|"error"|"gated"|"skipped", out, error, costUsd, ms }.
     * "gated": a ⚖️ Decide yes/no gate that answered no — it ran and billed, `out` holds its answer
     * ({ text: "no", decision }), and it carries `gate: { yes, message }`. Not an error.
     * "skipped" + `gatedBy: <decide node id>`: downstream of a closed gate — never ran, never billed.
     * (Annotation notes are "skipped" with no gatedBy.)
     */
    this.nodes = nodes;
    /** [{ nodeId, name, message }] for every node that failed (incl. non-sink warnings) — never gates */
    this.errors = errors;
    /**
     * [{ nodeId, name, message, yes, skipped: [nodeId…] }] — every Decide gate that closed this run.
     * A closed gate is a deliberate, successful outcome: run() resolves, it never throws for one.
     */
    this.gated = gated;
    /** summed USD cost of all calls that reported one */
    this.costUsd = costUsd;
    /** false when any network call omitted its price (total is a floor) */
    this.costExact = costExact;
    /** last remaining-balance the API reported, or null */
    this.remainingBalance = remainingBalance;
  }

  /** Output lookup by friendly key or node id (case-insensitive). */
  get(key) {
    // own-key check: `in` would leak Object.prototype members (get("toString") → a function)
    if (Object.hasOwn(this.outputs, key)) return this.outputs[key];
    const norm = String(key).trim().toLowerCase();
    for (const k of Object.keys(this.outputs)) {
      if (k.toLowerCase() === norm) return this.outputs[k];
    }
    const g = (this._gatedOutputs || []).find((o) => o.key.toLowerCase() === norm || o.nodeId.toLowerCase() === norm);
    if (g) throw new NanoodleError(`output "${g.key}" was skipped — the gate "${g.gateName}" answered no, so it never ran (see result.gated)`, { code: "gated" });
    throw new NanoodleError(`no output "${key}" — available outputs: ${Object.keys(this.outputs).map((k) => `"${k}"`).join(", ") || "(none)"}`);
  }
}

function isPlainObject(v) {
  if (v == null || typeof v !== "object") return false;
  const proto = Object.getPrototypeOf(v);
  return proto === Object.prototype || proto === null;
}

export class Workflow {
  /**
   * @param {object} graphData parsed noodle-graph.json
   * @param {{ apiKey?, payment?, baseUrl?, fetch?, pollIntervals?, timeouts?, quiet?, catalog? }} [opts]
   *   catalog: opt-in raw model-catalog arrays ({ chat, image, video, audio }) enabling
   *   the same payload gates play RUNTIME_JS applies (see src/catalog.mjs) — data only,
   *   never fetched by the library
   */
  constructor(graphData, opts = {}) {
    const { nodes, links, warnings } = materialize(graphData);
    this.graph = { nodes, links };
    this.catalog = opts.catalog || null;
    /**
     * Prompt character caps learned from live 400s ("kind:id" → cap), on top of the probed table in
     * prompt-caps.mjs. Per-instance and in-memory: a run that hits an unknown model's limit teaches
     * the next run of the same Workflow, which is where a retry actually happens.
     */
    this._promptCaps = new Map();
    /** Load-time warnings (unknown / unsupported node types). load() only warns; run() fails fast. */
    this.warnings = warnings;
    this.client = new NanoClient({
      apiKey: opts.apiKey !== undefined ? opts.apiKey : envApiKey(),
      baseUrl: opts.baseUrl,
      fetch: opts.fetch,
      pollIntervals: opts.pollIntervals,
      timeouts: opts.timeouts,
      payment: opts.payment, // accountless x402: a callback that sends the Nano invoice (never a seed)
    });
    /** [{ key, nodeId, field, kind, label, optional, def, options? }] */
    this.inputs = deriveInputs(this.graph);
    /** [{ key, nodeId, type, ports }] */
    this.outputs = deriveOutputs(this.graph);
    /** [{ key, nodeId, field, kind, def, options? }] */
    this.settings = deriveSettings(this.graph);
    if (warnings.length && !opts.quiet) {
      for (const w of warnings) warnGraph(w);
    }
  }

  /**
   * Load a workflow from a noodle-graph.json file on disk, or from any nanoodle
   * share link — a full URL (nanoodle.com/#g=…, /play.html#a=…, a da.gd/TinyURL
   * short link) or a bare #g=/#j=/#a= fragment. Direct fragment links decode
   * offline; only fragment-less short links touch the network (redirect-header
   * reads, no credentials attached).
   *
   * File paths use Node's `fs` (dynamic import). In browsers, pass a parsed
   * object / JSON string to `Workflow.fromJSON`, or a share URL/fragment.
   */
  static async load(src, opts = {}) {
    if (isShareRef(src)) {
      const { graph, recovered } = await decodeShareUrl(src, { fetch: opts.fetch });
      if (recovered && !opts.quiet) {
        warnGraph("share link was damaged (usually a copy/paste artifact) — recovered the graph's nodes and wires best-effort; re-copy the link from the editor for a pristine version");
      }
      return new Workflow(graph, opts);
    }
    if (typeof src === "string" && /^\s*[\[{]/.test(src)) {
      return Workflow.fromJSON(src, opts);
    }
    const { readFile } = await import("node:fs/promises");
    return Workflow.fromJSON(await readFile(src, "utf8"), opts);
  }

  /** Build from a parsed object or a JSON string. */
  static fromJSON(objOrString, opts = {}) {
    const data = typeof objOrString === "string" ? JSON.parse(objOrString) : objOrString;
    return new Workflow(data, opts);
  }

  /**
   * Execute the whole graph.
   * @param {object|string|Uint8Array|MediaRef} inputs friendly-keyed values, or a bare scalar
   *   when the workflow has exactly one required input
   * @param {{ settings?, defaults?, timeoutMs?, signal?, onProgress? }} [runOpts]
   *   defaults: false treats graph fields as authoritative — no def backfill for
   *   unsupplied inputs (the play UI materializes defs into fields itself, so a
   *   deliberately blank field must stay blank when it delegates to this engine)
   * @returns {Promise<RunResult>} rejects with RunError (carrying .result) when a sink failed
   */
  async run(inputs = {}, runOpts = {}) {
    const { settings = {}, defaults = true, timeoutMs, signal, onProgress } = runOpts;
    const graph = this.graph;

    // bare scalar → the single required input
    if (!isPlainObject(inputs)) {
      const required = this.inputs.filter((i) => !i.optional);
      if (required.length !== 1) {
        throw new NanoodleError(
          `a bare input value needs exactly one required input; this workflow has ${required.length} ` +
          `(${required.map((i) => `"${i.key}"`).join(", ")}) — pass an object instead`);
      }
      inputs = { [required[0].key]: inputs };
    }

    // ---- upfront validation: resolve every key BEFORE running/spending anything ----
    const inputAssignments = [];
    for (const [key, value] of Object.entries(inputs)) {
      const entry = resolveInputKey(graph, this.inputs, key);
      inputAssignments.push({ entry, value });
    }
    const settingAssignments = [];
    for (const [key, value] of Object.entries(settings)) {
      const entry = resolveSettingKey(graph, this.settings, key);
      const target = graph.nodes.find((x) => x.id === entry.nodeId);
      if (lockedNode(target)) {
        throw new NanoodleError(
          `setting "${key}" targets locked node ${entry.nodeId} (${displayName(target)}) — ` +
          `a locked node always runs with its stored fields, so settings can't override ${entry.nodeId}.${entry.field}`,
          { code: "locked" });
      }
      settingAssignments.push({ entry, value });
    }

    // unknown node types fail fast — before any network call
    for (const n of graph.nodes) {
      if (n.unknown) {
        throw new UnsupportedNodeError(
          `node ${n.id}: unknown node type '${n.type}' — this graph needs a newer nanoodle library`,
          { nodeId: n.id, nodeType: n.type });
      }
    }

    const order = topoSort(graph); // throws naming cyclic nodes

    // Local-only graphs never POST media — skip the ~4 MB inline cap on inputs.
    // Mixed/network graphs keep the cap so we fail before spending on an oversize body.
    const hasNetwork = graph.nodes.some((n) => NODE_TYPES[n.type] && NODE_TYPES[n.type].network);
    const mediaCoerceOpts = { enforceInlineMax: hasNetwork };

    // effective fields: graph fields + settings overrides + user inputs
    const effFields = new Map(graph.nodes.map((n) => [n.id, { ...n.fields }]));
    for (const { entry, value } of settingAssignments) {
      effFields.get(entry.nodeId)[entry.field] = this._coerceSetting(entry, value);
    }
    const explicit = new Set();
    for (const { entry, value } of inputAssignments) {
      effFields.get(entry.nodeId)[entry.field] = this._coerceInput(entry, value, mediaCoerceOpts);
      explicit.add(entry);
    }
    // vframes: raise frames to highest wired frameK (play.html wiredFramesFloor) so a
    // persisted frames=1 with frame3 wired doesn't starve the consumer after paid upstream.
    for (const n of graph.nodes) {
      if (n.type !== "vframes") continue;
      const fields = effFields.get(n.id);
      const floor = wiredFramesFloor(graph, n.id);
      const cur = Math.max(1, Math.min(MAX_FRAMES, parseInt(fields.frames, 10) || 1));
      if (floor > cur) fields.frames = String(floor);
    }
    // defaults + required check
    for (const entry of this.inputs) {
      const fields = effFields.get(entry.nodeId);
      const v = fields[entry.field];
      if (v == null || String(v).trim() === "") {
        // an EXPLICIT empty value clears an optional input (e.g. run with no system prompt) —
        // the def only backfills when the key wasn't supplied at all (the app's prefilled textarea)
        if (entry.optional && (explicit.has(entry) || !defaults)) continue;
        if (defaults && entry.def != null && String(entry.def) !== "") fields[entry.field] = entry.def;
        else if (!entry.optional) {
          throw new NanoodleError(`missing required input "${entry.key}" (${entry.nodeId}.${entry.field})`);
        }
      }
    }

    // API key (or an x402 payment callback) required only when the graph actually calls NanoGPT
    if (!this.client.apiKey && !this.client.payment && hasNetwork) {
      throw new NanoodleError("no API key — pass { apiKey } to Workflow.load/fromJSON, set NANOGPT_API_KEY, or pass { payment } for accountless x402 runs (this workflow calls the NanoGPT API)");
    }

    // ---- execution ----
    const ac = new AbortController();
    let timer = null;
    const onOuterAbort = () => ac.abort(signal.reason);
    if (signal) {
      if (signal.aborted) ac.abort(signal.reason);
      else signal.addEventListener("abort", onOuterAbort, { once: true });
    }
    if (timeoutMs) {
      timer = setTimeout(() => ac.abort(new NanoodleError(`run timed out after ${timeoutMs}ms`, { code: "timeout" })), timeoutMs);
    }

    const emit = (evt) => { if (onProgress) { try { onProgress(evt); } catch { /* listener errors never kill the run */ } } };
    const nodesRec = {};
    const errors = [];
    const cost = { total: 0, exact: true, balance: null };
    const byId = new Map(graph.nodes.map((n) => [n.id, n]));
    const promises = new Map();
    const mediaFetch = this.client.fetch;

    // Once a node is finalized (done / skipped / error) or the run has settled, late
    // callbacks from a runner that ignored its abort signal must not mutate anything.
    let runSettled = false;
    const frozen = (rec) => runSettled || rec.final === true;
    const ctxFor = (node, rec, nodeSignal = ac.signal) => {
      const onCost = (c) => {
        if (!c || frozen(rec)) return;
        if (c.usd != null) { rec.costUsd = (rec.costUsd || 0) + c.usd; cost.total += c.usd; }
        else cost.exact = false;
        if (c.balance != null) cost.balance = c.balance;
      };
      const onPoll = (info) => frozen(rec) ? undefined : emit({ type: "poll", nodeId: node.id, name: displayName(node), ...info });
      const io = { onCost, onPoll, signal: nodeSignal };
      return {
        chat: (messages, model, opts) => this.client.chat(messages, model, opts, io),
        decide: (body) => this.client.decide(body, io),
        image: (args) => this.client.image(args, io),
        video: (model, prompt, opts, imageDataUrl) => this.client.video(model, prompt, opts, imageDataUrl, io),
        audio: (model, input, extra) => this.client.audio(model, input, extra, io),
        transcribe: (model, audioUrl, language) => this.client.transcribe(model, audioUrl, language, io),
        fetchMedia: (url) => this.client.fetchMediaDataUrl(url, io),
        // local media (resize/combine/…) — same fetch + signal as network I/O
        fetch: mediaFetch,
        signal: nodeSignal,
        catalog: this.catalog,
        progress: (msg) => frozen(rec) ? undefined : emit({ type: "node-progress", nodeId: node.id, name: displayName(node), message: msg }),
      };
    };

    const gated = [];
    // a node whose upstream settled as a closed gate (or was itself skipped by one) → that gate's id
    const gateOf = (id) => {
      const r = nodesRec[id];
      if (!r) return null;
      if (r.status === "gated") return id;
      if (r.status === "skipped" && r.gatedBy) return r.gatedBy;
      return null;
    };
    const execNode = async (n) => {
      const rec = nodesRec[n.id];
      let nodeTimer = null, unlinkNode = null;
      try {
        throwIfAborted(ac.signal);
        const inbound = graph.links.filter((l) => l.to.node === n.id);
        const inp = {};
        let fields = effFields.get(n.id);
        let upstreamFail = null, gatedBy = null, skippedIn = 0;
        for (const l of inbound) {
          let srcOut;
          try {
            srcOut = await promises.get(l.from.node);
            if (nodesRec[l.from.node] && nodesRec[l.from.node].skippedOnError) { skippedIn++; continue; }
          }
          catch {
            const g = gateOf(l.from.node);
            if (g) { if (!gatedBy) gatedBy = g; } else if (!upstreamFail) upstreamFail = displayName(byId.get(l.from.node));
            continue;
          }
          const v = srcOut[l.from.port];
          if (isInputPort(n, l.to.port)) {
            // Node boundary: a relative content URL from the upstream provider is
            // resolved (authed redirect → absolute file URL, or inlined bytes)
            // before this node builds videoUrl / videoDataUrl / audio / image.
            inp[l.to.port] = (typeof v === "string" && v && HANDED_MEDIA_PORT.test(l.to.port))
              ? await this.client.resolveContentUrl(v, { signal: ac.signal })
              : v;
          }
          // Custom endpoint url/mode: a Choice path like "/post" must ride inp so
          // endpointResolveTarget can join it onto the typed host. Overwriting
          // fields.url with "/post" rejects the joined URL.
          else if (n.type === "endpoint" && (l.to.port === "url" || l.to.port === "mode")) {
            if (v != null) inp[l.to.port] = v;
          }
          // wired textarea port = field override; a missing upstream port (degraded save) must
          // NOT clobber the typed field with undefined — the app only applies v != null
          else if (v != null) fields = { ...fields, [l.to.port]: v };
        }
        // a real failure upstream wins over a gate (the browser runners agree): that is an error
        if (upstreamFail) throw new NanoodleError("upstream failed: " + upstreamFail);
        // onError:"skip" upstreams leave their ports undefined (ignored above). A node whose
        // EVERY wire comes from a skipped node has nothing left to work with — fail clearly.
        if (inbound.length && skippedIn === inbound.length) {
          throw new NanoodleError("all inputs were skipped after failing: " +
            [...new Set(inbound.map((l) => displayName(byId.get(l.from.node))))].join(", "));
        }
        if (gatedBy) {
          rec.status = "skipped";
          rec.gatedBy = gatedBy;
          const gr = gated.find((x) => x.nodeId === gatedBy);
          if (gr) gr.skipped.push(n.id);
          emit({ type: "node-skipped", nodeId: n.id, name: displayName(n), reason: "gated", gatedBy });
          throw new GateSkip(gatedBy);
        }
        throwIfAborted(ac.signal);
        // Prompt length caps (see prompt-caps.mjs). Many image/video models reject an over-long
        // prompt at the route, and in a graph the prompt is WRITTEN by an upstream LLM — so a
        // caller has nothing to shorten. Trim it to fit rather than send a request certain to 400,
        // and report it below. The graph's own prompts are never rewritten to avoid this.
        const fit = withFittedPrompt(n, fields, { catalog: this.catalog, learned: this._promptCaps });
        fields = fit.fields;
        rec.started = true;
        emit({ type: "node-start", nodeId: n.id, name: displayName(n) });
        // A fitted prompt changed what this run pays for — never silent, even headless.
        if (fit.trimmed) {
          emit({ type: "prompt-trimmed", nodeId: n.id, name: displayName(n), ...fit.trimmed });
          warnGraph(`node ${n.id}: prompt trimmed ${fit.trimmed.from} → ${fit.trimmed.to} characters — ` +
            `${fields.model} rejects prompts over ${fit.trimmed.cap}`);
        }
        const t0 = Date.now();
        // Per-node timeout (fields.timeoutMs): a child controller linked to the run signal.
        // The race guarantees the deadline even if a runner never observes its signal.
        const timeoutMs = Number(fields.timeoutMs);
        let nodeSignal = ac.signal, deadline = null;
        if (Number.isFinite(timeoutMs) && timeoutMs > 0) {
          const nac = new AbortController();
          const onRunAbort = () => nac.abort(ac.signal.reason);
          ac.signal.addEventListener("abort", onRunAbort, { once: true });
          unlinkNode = () => ac.signal.removeEventListener("abort", onRunAbort);
          nodeSignal = nac.signal;
          deadline = new Promise((_, reject) => {
            nodeTimer = setTimeout(() => {
              const err = new NanoodleError(`node timed out after ${timeoutMs}ms`, { code: "timeout" });
              nac.abort(err);
              reject(err);
            }, timeoutMs);
          });
          deadline.catch(() => {});
        }
        const nodeForRun = { ...n, fields };
        const work = RUNNERS[n.type](nodeForRun, inp, ctxFor(n, rec, nodeSignal));
        const rawOut = deadline ? await Promise.race([work, deadline]) : await work;
        if (deadline) throwIfAborted(nodeSignal);
        throwIfAborted(ac.signal);
        // Final outputs of this node are absolute usable URLs, not the relative
        // content path the provider returned. Downstream reads this same object.
        const out = await publishNodeMedia(this.client, nodeForRun, rawOut, nodeSignal);
        throwIfAborted(ac.signal);
        rec.final = true;
        rec.status = "done";
        rec.out = out;
        rec.ms = Date.now() - t0;
        emit({ type: "node-done", nodeId: n.id, name: displayName(n), ms: rec.ms, costUsd: rec.costUsd });
        return out;
      } catch (e) {
        rec.final = true;
        if (e instanceof GateSkip) throw e;
        // ⚖️ Decide gate answered no: a settled, billed decision — not an error. Downstream skips.
        if (e && e.gate === true && !ac.signal.aborted) {
          rec.status = "gated";
          rec.out = e.out || null;
          rec.gate = { yes: e.decision && typeof e.decision.yes === "number" ? e.decision.yes : null, message: e.message };
          gated.push({ nodeId: n.id, name: displayName(n), message: e.message, yes: rec.gate.yes, skipped: [] });
          emit({ type: "node-gated", nodeId: n.id, name: displayName(n), message: e.message, yes: rec.gate.yes, costUsd: rec.costUsd });
          throw e;
        }
        // A prompt-length rejection is free (nothing generated) and, once banked, preventable: the
        // next run budgets the LLM above this node and fits whatever is left. Say that, rather than
        // relaying "please shorten it" about a prompt the caller never wrote.
        if (learnPromptCap(this._promptCaps, n, e.message)) {
          e.message = e.message + " — noted: nanoodle keeps this model's prompt inside that limit from now on, so running again should succeed";
        }
        rec.error = e.message;
        errors.push({ nodeId: n.id, name: displayName(n), message: e.message, ...(e && e.code ? { code: e.code } : {}) });
        // fields.onError:"skip" — a failed (or timed-out) node is recorded and skipped; its
        // dependents see undefined ports. A run-level abort/timeout is never skipped.
        const onError = (effFields.get(n.id) || {}).onError;
        if (onError === "skip" && !ac.signal.aborted) {
          rec.status = "skipped";
          rec.skippedOnError = true;
          rec.out = {};
          emit({ type: "node-skipped", nodeId: n.id, name: displayName(n), reason: "error", error: e.message });
          return {};
        }
        rec.status = "error";
        emit({ type: "node-error", nodeId: n.id, name: displayName(n), error: e.message });
        throw e;
      } finally {
        if (nodeTimer) clearTimeout(nodeTimer);
        if (unlinkNode) unlinkNode();
      }
    };

    try {
      for (const n of order) {
        if (NODE_TYPES[n.type].note) { nodesRec[n.id] = { status: "skipped", out: null, error: null, costUsd: null, ms: null }; continue; }
        nodesRec[n.id] = { status: "pending", out: null, error: null, costUsd: null, ms: null };
        promises.set(n.id, execNode(n)); // siblings run concurrently; a node starts when ITS deps finish
      }
      await Promise.allSettled([...promises.values()]);
    } finally {
      runSettled = true;
      if (timer) clearTimeout(timer);
      if (signal) signal.removeEventListener("abort", onOuterAbort);
    }

    // A network node that started but was skipped, timed out or aborted without ever reporting
    // a price may still have been billed: the total can't be exact.
    for (const n of order) {
      const rec = nodesRec[n.id];
      const t = NODE_TYPES[n.type];
      if (!rec || !rec.started || rec.status === "done" || rec.costUsd != null || (t && t.local)) continue;
      cost.exact = false;
    }
    // ---- result ----
    const outputsMap = {};
    for (const o of this.outputs) {
      const rec = nodesRec[o.nodeId];
      if (!rec || !(rec.status === "done" || (rec.status === "gated" && rec.out))) continue;
      const primary = o.ports[0];
      const value = this._wrapValue(rec.out[primary.name], primary.type);
      outputsMap[o.key] = value;
      outputsMap[o.nodeId] = value;
    }
    const result = new RunResult({
      outputs: outputsMap,
      nodes: nodesRec,
      errors,
      gated,
      costUsd: cost.total,
      costExact: cost.exact,
      remainingBalance: cost.balance,
    });
    // sinks a closed gate skipped: get() names the gate instead of "no output"
    Object.defineProperty(result, "_gatedOutputs", {
      enumerable: false,
      value: this.outputs.filter((o) => nodesRec[o.nodeId] && nodesRec[o.nodeId].gatedBy)
        .map((o) => ({ key: o.key, nodeId: o.nodeId, gateName: displayName(byId.get(nodesRec[o.nodeId].gatedBy)) })),
    });

    // timeout/abort must fail the run even when local media finished after the deadline
    // (or nodes never observed the signal). Prefer the abort reason when present.
    if (ac.signal.aborted) {
      const reason = abortReason(ac.signal);
      const msg = reason.message || "run aborted";
      // mark any still-pending nodes so result.errors is complete
      for (const n of order) {
        const rec = nodesRec[n.id];
        if (rec && rec.status === "pending") {
          rec.status = "error";
          rec.error = msg;
          if (!errors.some((e) => e.nodeId === n.id)) {
            errors.push({ nodeId: n.id, name: displayName(n), message: msg });
          }
        }
      }
      throw new RunError(msg, result, reason.code ? { code: reason.code } : {});
    }

    const failedSinks = this.outputs.filter((o) => nodesRec[o.nodeId] && nodesRec[o.nodeId].status === "error");
    if (failedSinks.length) {
      let detail = failedSinks.map((o) => `"${o.key}": ${nodesRec[o.nodeId].error}`).join("; ");
      // "upstream failed: X" only names the sink's neighbor — name the node(s) that actually broke
      const sinkIds = new Set(failedSinks.map((o) => o.nodeId));
      const roots = errors.filter((e) => !sinkIds.has(e.nodeId) && !/^upstream failed: /.test(e.message));
      if (roots.length) {
        detail += ` (root cause — ${roots.map((e) => `"${e.name}": ${e.message}`).join("; ")})`;
      }
      throw new RunError("run failed — " + detail, result);
    }
    // onError:"skip" never makes a run succeed with nothing: if every output skipped, fail.
    const skippedSinks = this.outputs.filter((o) => nodesRec[o.nodeId] && nodesRec[o.nodeId].skippedOnError);
    if (this.outputs.length && skippedSinks.length === this.outputs.length) {
      throw new RunError("run failed — every output was skipped after failing: " +
        skippedSinks.map((o) => `"${o.key}": ${nodesRec[o.nodeId].error}`).join("; "), result);
    }
    return result;
  }

  _coerceInput(entry, value, mediaOpts) {
    if (MEDIA_KINDS.has(entry.kind)) {
      // Plain image inputs skip the load-time inline cap: every image-sending node
      // downscales an oversized image to the send budget (fitImage), so a big photo
      // is a shrink, not a refusal. Audio/video (and inpaint, whose mask must keep
      // the source's dimensions) can't be shrunk that way — keep their early,
      // before-any-spend guard.
      const opts = entry.kind === "image" ? { ...mediaOpts, enforceInlineMax: false } : mediaOpts;
      return coerceMediaInput(value, `input "${entry.key}"`, opts);
    }
    if (entry.kind === "choice") {
      const v = String(value);
      if (!(entry.options || []).includes(v)) {
        throw new NanoodleError(`input "${entry.key}": "${v}" is not one of the choices (${(entry.options || []).join(", ")})`);
      }
      return v;
    }
    if (value != null && typeof value === "object" && !(value instanceof String)) {
      throw new NanoodleError(`input "${entry.key}" expects text — got ${Array.isArray(value) ? "an array" : "an object"}`);
    }
    return value == null ? value : String(value);
  }

  _coerceSetting(entry, value) {
    // settings come from DOM inputs in the app, so runners assume strings — coerce scalars
    // (numbers/booleans) the same way instead of crashing a runner mid-run
    if (value == null) return value;
    if (typeof value === "object" && !(value instanceof String)) {
      throw new NanoodleError(`setting "${entry.key}" expects a scalar — got ${Array.isArray(value) ? "an array" : "an object"}`);
    }
    return String(value);
  }

  _wrapValue(value, portType) {
    if (portType !== "text" && typeof value === "string" && value) {
      return new MediaRef(value, { fetch: this.client.fetch });
    }
    return value;
  }
}
