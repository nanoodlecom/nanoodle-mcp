// Up-front run-cost estimate for a graph — a USD forecast computed from the
// public NanoGPT catalog BEFORE anything runs. Pure: it never fetches. The
// caller supplies the raw catalog arrays (the same ones the /api/v1/*-models
// endpoints return); this module walks the graph's billable nodes, prices each
// against its chosen model, and sums.
//
// This is the twin of the editor/play "~$X to run" chip (index.html /
// play.html): the resolver math is ported node-for-node so a hosted server and
// the app forecast the same number. Image is exact; chat/video/audio are
// estimates (marked `exact:false`) because their true cost depends on how many
// tokens/seconds the run actually produces. `unpriced` counts billable nodes we
// could not price (model missing from the catalog, or a pricing shape we don't
// recognise) — a nonzero count means the sum is a LOWER bound.
//
// Cost is only ever KNOWN after a run (the API reports it); this is the forecast
// that lets a paid server quote a deposit that actually covers the call on the
// very first request, instead of a flat guess.

import { REF_PORT_RE } from "./graph.mjs";
import { pricingAdvertisesRefs } from "./catalog.mjs";
import { cleanVoiceEstSeconds, CLEANVOICE_DEFAULT_MODEL } from "./cleanvoice.mjs";
import { strictNumber, strictUsd } from "./x402.mjs";

const MODEL3D_DEFAULT_MODEL = "tripo3d/v2.5";

/** Model id the run will actually send: the field, or the runner's default when the field is blank. */
function pricedModelId(node) {
  const id = node.fields && String(node.fields.model || "").trim();
  if (id) return id;
  if (node.type === "model3d") return MODEL3D_DEFAULT_MODEL;
  if (node.type === "cleanvoice") return CLEANVOICE_DEFAULT_MODEL;
  return "";
}

// node type → pricing "kind" == which catalog it's priced from + which unit fn.
// Mirrors the app's SETTING_MODEL_KIND. This set is exactly the billable
// (network) node types; a type absent here is a free local node and costs $0.
//
// The retired `draw` type is deliberately absent. It priced as "chat" until
// 2026-07-22, when NanoGPT dropped the gemini-omni chat-image contract. The
// loader now treats `draw` as an unknown type: it warns on load and throws
// UnsupportedNodeError at run(), before any network call. So a `draw` node in a
// legacy graph never spends, and pricing it would quote a caller for a call
// that cannot happen. It contributes $0 and is not counted as `unpriced`,
// because "we could not price it" is the wrong report — it is not billable.
const PRICE_KIND = {
  llm: "chat", vision: "chat", decide: "chat",
  image: "image", edit: "image", inpaint: "image",
  tvideo: "video", ivideo: "video", vedit: "video", lipsync: "video",
  music: "audio", remix: "audio", tts: "audio", transcribe: "audio", cleanvoice: "audio",
  model3d: "model3d",
};

// Fallback assumptions when a run's real quantity isn't knowable up front.
const EST = { llmInTokens: 1000, llmOutTokens: 500, ttsChars: 600, audioSeconds: 30, sttMinutes: 1, videoFps: 30 };

const _num = strictNumber;

function pickByRes(map, reqRes, defRes) {
  if (!map || typeof map !== "object") return null;
  if (reqRes != null && _num(map[reqRes]) != null) return _num(map[reqRes]);
  if (defRes != null && _num(map[defRes]) != null) return _num(map[defRes]);
  const vals = Object.values(map).map(_num).filter((v) => v != null);
  return vals.length ? vals[0] : null;
}
function pickObjByRes(map, reqRes, defRes) {
  if (!map || typeof map !== "object") return null;
  if (reqRes != null && map[reqRes] && typeof map[reqRes] === "object") return map[reqRes];
  if (defRes != null && map[defRes] && typeof map[defRes] === "object") return map[defRes];
  const objs = Object.values(map).filter((v) => v && typeof v === "object");
  return objs.length ? objs[0] : null;
}
function pickDur(p, raw, fields) {
  const f = parseFloat(fields && fields.duration);
  if (isFinite(f) && f > 0) return f;
  const d = _num(p.default_duration) ?? _num(raw.defaultDuration);
  if (d != null && d > 0) return d;
  if (p.per_duration) { const k = Object.keys(p.per_duration)[0]; const n = strictNumber(k); if (n != null && n > 0) return n; }
  if (Array.isArray(p.supported_durations) && p.supported_durations.length) { const n = strictNumber(p.supported_durations[0]); if (n != null && n > 0) return n; }
  if (p.fixed_duration_seconds != null) return _num(p.fixed_duration_seconds) || 5;
  return 5;
}

// A LoRA row counts only once it carries a URL. loraParams sends nothing for a
// blank row, so a blank row must not flip the estimate onto the LoRA tier.
function videoLoraOn(fields) {
  const f = fields || {};
  const rows = Array.isArray(f.loras) ? f.loras : (String(f.loraUrl || "").trim() ? [{ url: f.loraUrl }] : []);
  return rows.some((r) => r && String(r.url || "").trim() !== "");
}

// Untouched audio switch: modelOpts omits the key. The checkbox paints the catalog
// default and only writes it once the user flips it; the generate-video body omits
// it the same way. NanoGPT then bills that catalog default (42 models default on).
// An explicit false stays on the silent tier. No param descriptor stays off.
function videoAudioOn(fields, audioCtx) {
  const f = fields || {};
  const opts = (f.modelOpts && typeof f.modelOpts === "object") ? f.modelOpts : {};
  let explicit = false;
  for (const k in opts) {
    if (/audio/i.test(k) && !/^(no|disable|without|mute)/i.test(k)) {
      explicit = true;
      const val = opts[k];
      if (val === true || val === "true" || val === 1 || val === "1" || val === "on" || val === "yes") return true;
    }
  }
  if (explicit) return false;
  const ctx = audioCtx || {}, pp = ctx.params || {}, dflt = ctx.defaults || {};
  for (const k of Object.keys(pp)) {
    const d = pp[k];
    if (!d || typeof d !== "object") continue;
    if (d.type !== "switch" && d.type !== "boolean") continue;
    if (!/audio/i.test(k) || /^(no|disable|without|mute)/i.test(k)) continue;
    const def = dflt[k] != null ? dflt[k] : d.default;
    return def === true || def === "true" || def === 1 || def === "1" || def === "on" || def === "yes";
  }
  return false;
}

// A video run bills a HIGHER tier when reference images are wired or the model's
// audio switch is on. refWired comes from the graph wiring; the audio switch /
// reference mode ride in fields.modelOpts. refWired may be a boolean (legacy
// "any refs?") or a count of wired refN ports. audioCtx is
// { params, defaults } from the catalog's supported_parameters — an untouched
// switch uses that default instead of assuming audio off.
function videoUnitUsd(pricing, fields, refWired, audioCtx) {
  const p = pricing || {};
  const f = fields || {};
  const opts = (f.modelOpts && typeof f.modelOpts === "object") ? f.modelOpts : {};
  const audioOn = videoAudioOn(f, audioCtx);
  const refCount = typeof refWired === "number" ? Math.max(0, refWired | 0) : (refWired ? 1 : 0);
  const refOn = refCount > 0 || /reference/i.test(String(opts.mode || ""));
  let usd = videoBaseUsd(p, f, audioOn, refOn);
  if (usd != null && isFinite(usd) && audioOn && p.audio_multiplier != null) usd *= (_num(p.audio_multiplier) ?? 1);
  // MiniMax H3 LoRA: each wired reference image/audio adds
  // pricing.lora.reference_image_or_audio ($0.02). This number is the quote,
  // not the hold. x402 settlement on POST /api/generate-video (402
  // payment.amountUsd, nothing runs) matches it with no added headroom:
  // LoRA 5s 480p $0.25, +1 ref $0.32, +2 $0.34. GET /api/estimate-video-cost
  // ignores lora/ref fields and stays on the non-LoRA floor ($0.65); this
  // forecast does not. nanoodle-mcp's deposit (gate priceFor:
  // ceil(basis × 1.2 × 2) for inexact video, 1.25× when exact) is applied by
  // that caller on top of this usd and is intentionally left unchanged.
  if (usd != null && isFinite(usd) && refCount > 0 && videoLoraOn(f)) {
    const tier = (p.lora && typeof p.lora === "object") ? p.lora : null;
    const per = tier && _num(tier.reference_image_or_audio);
    if (per != null) usd += per * refCount;
  }
  return usd;
}
function videoBaseUsd(pricing, fields, audioOn, refOn) {
  const p = pricing || {}, raw = (p.raw && typeof p.raw === "object") ? p.raw : {};
  const f = fields || {};
  const res = f.resolution, defRes = p.default_resolution ?? raw.defaultResolution;
  const dur = pickDur(p, raw, f);
  const rp = (m) => pickByRes(m, res, defRes);
  let v;
  if ((v = rp(p.per_second_by_resolution)) != null) return v * dur;
  if ((v = rp(p.standard_prices_per_second)) != null) return v * dur;
  if (p.per_second_by_mode) {
    const mm = p.per_second_by_mode;
    v = refOn ? (_num(mm.reference_to_video_image) ?? _num(mm.reference_to_video_video)) : null;
    if (v == null) v = _num(mm.text_to_video) ?? pickByRes(mm);
    if (v != null) return v * dur;
  }
  if (audioOn) {
    for (const k of ["text_image_with_audio_per_second", "image_to_video_with_audio_per_second", "text_to_video_with_audio_per_second"]) {
      if (p[k] != null) { v = (typeof p[k] === "object") ? rp(p[k]) : _num(p[k]); if (v != null) return v * dur; }
    }
  }
  for (const k of ["text_to_video_per_second", "text_image_without_audio_per_second", "image_to_video_without_audio_per_second"]) {
    if (p[k] != null) { v = (typeof p[k] === "object") ? rp(p[k]) : _num(p[k]); if (v != null) return v * dur; }
  }
  if (p.base_price_per_second != null) { const m = p.resolution_multipliers ? (rp(p.resolution_multipliers) ?? 1) : 1; v = _num(p.base_price_per_second); if (v != null) return v * dur * m; }
  if (p.per_second != null) { v = _num(p.per_second); if (v != null) return v * dur; }
  if (p.per_duration) { const dk = String(Math.round(dur)); v = _num(p.per_duration[dk]) ?? _num(p.per_duration[String(dur)]) ?? pickByRes(p.per_duration); if (v != null) return v; }
  if (p.without_audio != null || p.with_audio != null) { v = audioOn ? (_num(p.with_audio) ?? _num(p.without_audio)) : (_num(p.without_audio) ?? _num(p.with_audio)); if (v != null) return v; }
  if (p.base_prices_by_resolution) {
    const dk = String(Math.round(dur));
    if (p.duration_overrides && p.duration_overrides[dk]) { v = rp(p.duration_overrides[dk]); if (v != null) return v; }
    const base = rp(p.base_prices_by_resolution);
    let mult = 1;
    if (p.duration_multiplier != null) mult = _num(p.duration_multiplier) ?? 1;
    else if (p.duration_multipliers) mult = _num(p.duration_multipliers[dk]) ?? pickByRes(p.duration_multipliers) ?? 1;
    if (base != null) return base * mult;
  }
  if ((v = rp(p.per_resolution)) != null) return v;
  if (p.base_price != null && p.per_extra_second != null) { const bd = _num(p.base_duration) || 0; return _num(p.base_price) + Math.max(0, dur - bd) * _num(p.per_extra_second); }
  if (p.per_video != null) { v = _num(p.per_video); if (v != null) return v; }
  if (p.per_target_megapixel_second != null) { const mp = _num(p.default_target_megapixels) || 1; v = _num(p.per_target_megapixel_second) * mp * dur; return Math.max(v, _num(p.minimum_price) || 0); }
  if (p.per_frame_unit != null) { const fpu = _num(p.frames_per_unit) || 1; return (dur * EST.videoFps / fpu) * _num(p.per_frame_unit); }
  if (p.base_price != null) { v = _num(p.base_price); if (v != null) return v; }
  if (Object.keys(raw).length) {
    if (refOn) {
      if (raw.referenceToVideoPrices) { const inner = pickObjByRes(raw.referenceToVideoPrices, res, defRes); if (inner) { const dk = String(Math.round(dur)); v = _num(inner[dk]) ?? pickByRes(inner); if (v != null) return v; } }
      for (const k of ["textToVideoWithReferenceVideoPricesPerSecond", "standardTextToVideoWithReferenceVideoPricesPerSecond", "turboTextToVideoWithReferenceVideoPricesPerSecond",
        "standardReferenceVideoPricesPerSecond", "fastReferenceVideoPricesPerSecond"]) {
        if (raw[k]) { v = pickByRes(raw[k], res, defRes); if (v != null) return v * dur; }
      }
    }
    if (audioOn) {
      if (raw.withAudioPricesPerSecond) { v = pickByRes(raw.withAudioPricesPerSecond, res, defRes); if (v != null) return v * dur; }
      if (raw.withAudioPrices) { const inner = pickObjByRes(raw.withAudioPrices, res, defRes); if (inner) { const dk = String(Math.round(dur)); v = _num(inner[dk]) ?? pickByRes(inner); if (v != null) return v; } }
    }
    for (const k of ["pricesPerSecond", "textToVideoPricesPerSecond", "withoutAudioPricesPerSecond",
      "standardPricesPerSecond", "standardTextToVideoPricesPerSecond", "outputPricesPerSecond", "fastPricesPerSecond"]) {
      if (raw[k]) { v = pickByRes(raw[k], res, defRes); if (v != null) return v * dur; }
    }
    for (const k of ["withoutAudioPrices", "withAudioPrices", "referenceToVideoPrices"]) {
      if (raw[k]) { const inner = pickObjByRes(raw[k], res, defRes); if (inner) { const dk = String(Math.round(dur)); v = _num(inner[dk]) ?? pickByRes(inner); if (v != null) return v; } }
    }
    if (raw.pricePerMegapixel != null && raw.megapixelsByResolution) {
      const mp = _num(raw.megapixelsByResolution[res]) ?? _num(raw.megapixelsByResolution[defRes]) ?? pickByRes(raw.megapixelsByResolution);
      const nf = _num(raw.defaultNumFrames) || (dur * (_num(raw.defaultFramesPerSecond) || 24));
      if (mp != null) return _num(raw.pricePerMegapixel) * mp * nf;
    }
  }
  // MiniMax H3 with a LoRA URL. Without one, fall through: non-LoRA H3 stays
  // on genericScanUsd (output_per_second × duration → 5s $0.65) and every
  // other shape keeps its existing handler. A LoRA URL switches to
  // lora.text_or_image_per_second by resolution, or lora.reference_per_second
  // once refs are wired. The per-ref surcharge is added in videoUnitUsd.
  if (p.output_per_second != null && p.lora && typeof p.lora === "object" && videoLoraOn(f)) {
    const L = p.lora;
    const billSecs = (d, lo, hi) => Math.min(_num(hi) ?? d, Math.max(_num(lo) ?? d, d));
    const tbl = (refOn && L.reference_per_second) ? L.reference_per_second : L.text_or_image_per_second;
    v = (tbl && typeof tbl === "object") ? rp(tbl) : _num(tbl);
    if (v != null) return v * billSecs(dur, L.min_duration, L.max_duration);
  }
  return genericScanUsd(p, dur);
}
// Last resort so a never-seen pricing shape estimates SOMETHING rather than
// blanking: the smallest per-second number scaled by duration, else the
// smallest flat number.
function genericScanUsd(p, dur) {
  let perSec = null, flat = null;
  (function walk(o, key) {
    if (o == null) return;
    if (typeof o === "number") { if (o > 0 && o < 500) { if (/second|persec/i.test(key)) perSec = Math.min(perSec ?? Infinity, o); else flat = Math.min(flat ?? Infinity, o); } return; }
    if (typeof o === "object") for (const k of Object.keys(o)) walk(o[k], k);
  })(p, "");
  if (perSec != null) return perSec * dur;
  if (flat != null) return flat;
  return null;
}
function chatUnitUsd(pricing, inTok, outTok) {
  if (!pricing) return null;
  const pin = _num(pricing.prompt), pout = _num(pricing.completion);   // $ per 1M tokens
  if (pin == null && pout == null) return null;                        // omni "varies_by_modality" → unknown
  return ((pin || 0) * (inTok ?? EST.llmInTokens) + (pout || 0) * (outTok ?? EST.llmOutTokens)) / 1e6;
}
function audioUnitUsd(pricing, chars, seconds) {
  const p = pricing || {}, c = chars ?? EST.ttsChars;
  const secs = (seconds != null && isFinite(seconds)) ? seconds : EST.audioSeconds;
  if (p.per_thousand_chars != null) { let cost = _num(p.per_thousand_chars) * (c / 1000); if (p.per_generation != null) cost += _num(p.per_generation); return Math.max(cost, _num(p.minimum) || 0); }
  if (p.per_prompt_char_block != null) { const bs = _num(p.prompt_char_block_size) || 1; return Math.max(Math.ceil(c / bs) * _num(p.per_prompt_char_block), _num(p.minimum) || 0); }
  if (p.per_generation != null) return _num(p.per_generation);
  if (p.per_second != null) return Math.max(_num(p.per_second) * secs, _num(p.minimum) || 0);
  // per started billing interval (ElevenLabs Music / VEED Clean Audio: $/started minute)
  if (p.per_billing_interval != null) {
    const iv = _num(p.billing_interval_seconds) || 60;
    return Math.max(Math.ceil(secs / iv) * _num(p.per_billing_interval), _num(p.minimum) || 0);
  }
  if (p.per_minute != null) return _num(p.per_minute) * EST.sttMinutes;
  return null;
}
// Seconds a per_second audio model is billed for: the node's duration clamped to
// the model's advertised min/max_duration. null → audioUnitUsd uses EST.audioSeconds.
function audioBilledSeconds(sp, fields) {
  const p = sp || {};
  if (p.min_duration == null || p.max_duration == null) return null;
  const d = parseFloat(fields && fields.duration);
  if (!isFinite(d)) return null;
  const lo = _num(p.min_duration), hi = _num(p.max_duration);
  return Math.min(hi != null ? hi : d, Math.max(lo != null ? lo : d, d));
}
function imageUsd(pricing, size, count) {
  const per = (pricing && pricing.per_image) || {};
  const v = per[size] ?? per.square ?? per.square_hd ?? Object.values(per)[0];
  const n = strictUsd(v);
  return n == null ? null : n * (count || 1);
}

/** Which pricing kinds a graph touches — so a caller fetches only the catalogs it needs. */
export function graphModelKinds(graph) {
  const kinds = new Set();
  for (const n of (graph && graph.nodes) || []) { const k = PRICE_KIND[n.type]; if (k) kinds.add(k); }
  return kinds;
}

// One node's USD/run from its chosen model + settings. `catItem` is the raw
// catalog entry for node.fields.model (null → unpriceable). `graph` is needed
// only to detect wired reference-image ports (video ref tier).
function nodeUnitUsd(node, catItem, graph) {
  const kind = PRICE_KIND[node.type]; if (!kind) return null;
  const id = pricedModelId(node); if (!id) return null;
  const m = catItem; if (!m) return null;
  const pricing = m.pricing, f = node.fields || {};
  if (kind === "image") {
    const sp = m.supported_parameters || {}, maxOut = sp.max_output_images || 1, fixed = sp.fixed_image_count || 0;
    const count = fixed > 1 ? fixed : Math.min(maxOut, Math.max(1, parseInt(f.variations, 10) || 1));   // fixed>1 = the model dictates the count; fixed 1 falls through to the variations clamp
    return imageUsd(pricing, f.size, count);
  }
  if (kind === "video") {
    const sp = m.supported_parameters || {}, pp = sp.parameters || sp;
    const modelHasRefs = ["reference_images", "reference_image_urls", "referenceImages"].some((k) => k in pp) ||
      pricingAdvertisesRefs(pricing); // twin of modelRefSpec: refs the run WILL send must forecast at the ref tier
    // Count, not a boolean: H3 LoRA adds reference_image_or_audio once per wired refN port.
    const refCount = (modelHasRefs && graph && Array.isArray(graph.links))
      ? graph.links.filter((l) => l.to && l.to.node === node.id && REF_PORT_RE.test(l.to.port)).length
      : 0;
    const audioCtx = { params: (sp.parameters && typeof sp.parameters === "object") ? sp.parameters : {}, defaults: sp.defaults || {} };
    const u = videoUnitUsd(pricing, f, refCount, audioCtx);
    return (u != null && isFinite(u)) ? u : null;
  }
  if (kind === "model3d") return _num(pricing && pricing.per_run);
  if (node.type === "decide") {
    // input tokens only (twin of the editor's Decide estimate); pick asks twice (in order + reversed)
    const imgs = (graph && Array.isArray(graph.links))
      ? graph.links.filter((l) => l.to && l.to.node === node.id && /^img\d+$/.test(l.to.port)).length : 0;
    const inTok = 120 + Math.round(((f.question || "").length + (f.options || "").length + (f.levels || "").length) / 4) + 250 + imgs * 400;
    const u = chatUnitUsd(pricing, inTok, 0);
    const pick = !(f.mode === "choose" || f.mode === "score" || f.mode === "yesno");
    return u == null ? null : u * (pick ? 2 : 1);
  }
  if (kind === "chat") {
    const inTok = Math.max(200, Math.round(((f.system || "").length + (f.prompt || "").length) / 4) + 200);
    const outTok = f.maxTokens ? +f.maxTokens : EST.llmOutTokens;
    return chatUnitUsd(pricing, inTok, outTok);
  }
  if (kind === "audio") {
    if (node.type === "cleanvoice") {
      // Bills the wired source's duration knob (else 30 s). per_minute models ignore seconds.
      const link = graph && Array.isArray(graph.links)
        ? graph.links.find((l) => l.to && l.to.node === node.id && (l.to.port === "audio" || l.to.port === "video"))
        : null;
      const src = link && Array.isArray(graph.nodes) ? graph.nodes.find((x) => x.id === link.from.node) : null;
      const u = audioUnitUsd(pricing, undefined, cleanVoiceEstSeconds(src && src.fields));
      return (u != null && isFinite(u)) ? u : null;
    }
    const chars = node.type === "transcribe" ? undefined : ((f.prompt || "").length || EST.ttsChars);
    const secs = audioBilledSeconds(m.supported_parameters, f);
    const u = audioUnitUsd(pricing, chars, secs);
    return (u != null && isFinite(u)) ? u : null;   // one track — the sent song count is clamped to 1 at run
  }
  return null;
}

/**
 * Forecast a graph's per-run cost from the public catalog.
 *
 * @param {{nodes:Array, links?:Array}} graph  a materialized graph (Workflow#graph)
 * @param {{chat?:Array, image?:Array, video?:Array, audio?:Array, model3d?:Array}} catalogs
 *        raw catalog arrays (as /api/v1/*-models return them, `.data`), indexed here by model id
 * @returns {{usd:number, exact:boolean, priced:number, unpriced:number}}
 *          usd = sum over priced billable nodes; exact = every priced node was image
 *          (deterministic); priced/unpriced = billable node counts. unpriced>0 ⇒ usd is a lower bound.
 */
export function estimateGraphCost(graph, catalogs = {}) {
  const nodes = (graph && Array.isArray(graph.nodes)) ? graph.nodes : [];
  const byKind = {};
  for (const kind of ["chat", "image", "video", "audio", "model3d"]) {
    const arr = Array.isArray(catalogs[kind]) ? catalogs[kind] : [];
    const map = new Map();
    for (const m of arr) if (m && m.id != null) map.set(String(m.id), m);
    byKind[kind] = map;
  }
  let usd = 0, priced = 0, unpriced = 0, exact = true;
  for (const n of nodes) {
    const kind = PRICE_KIND[n.type]; if (!kind) continue;   // free/local node
    const id = pricedModelId(n);
    const m = id ? byKind[kind].get(String(id)) : null;
    const u = m ? nodeUnitUsd(n, m, graph) : null;
    if (u == null || !isFinite(u)) { unpriced++; continue; }
    usd += u; priced++;
    if (kind === "model3d") {
      const by = m.pricing && m.pricing.per_run_by_variant;
      if (by && typeof by === "object") {
        const vals = Object.values(by).map(_num).filter((v) => v != null);
        if (vals.length && Math.min(...vals) !== Math.max(...vals)) exact = false;
      }
    } else if (kind !== "image") exact = false;
  }
  return { usd, exact, priced, unpriced };
}
