import { dataUrlBytes, sniffMime } from "./media.mjs";

import { trs, unpackGlb } from "./gltf-scene.mjs";
import { prepareClip } from "./gltf-animation.mjs";
import { sceneNodes, readSkin, skinInfluences, skinMatrices, posedPositions } from "./gltf-skin.mjs";

const decodeText = (bytes) => new TextDecoder().decode(bytes);
const components = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };
const glTypes = {
  5120: [1, "getInt8", 127],
  5121: [1, "getUint8", 255],
  5122: [2, "getInt16", 32767],
  5123: [2, "getUint16", 65535],
  5125: [4, "getUint32", 4294967295],
  5126: [4, "getFloat32", 1],
};

function unpack(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length < 4 || view.getUint32(0, true) !== 0x46546c67) {
    try {
      return { json: JSON.parse(decodeText(bytes)) };
    } catch {
      throw new Error("Expected a GLB, a self-contained glTF 2 mesh, or a Gaussian PLY.");
    }
  }
  return unpackGlb(bytes);
}

function embedded(uri) {
  if (!uri?.startsWith("data:"))
    throw new Error("External glTF buffers and images require a self-contained .gltf or .glb export.");
  return dataUrlBytes(uri);
}

export async function triangleModel(bytes, imagePixels) {
  return (await trianglePoses(bytes, imagePixels)).pose(0);
}

export async function trianglePoses(bytes, imagePixels, { clip = "", frames = 1 } = {}) {
  const { json, bin } = unpack(bytes);
  if (json?.asset?.version !== "2.0") throw new Error("Expected glTF 2.0.");
  const unsupported = (json.extensionsRequired || []).filter((name) => name !== "EXT_texture_webp");
  if (unsupported.length) throw new Error("Unsupported required glTF extensions: " + unsupported.join(", "));
  const buffers = (json.buffers || []).map((b, i) => {
    const data = b.uri ? embedded(b.uri).bytes : i === 0 && bin;
    if (!data || data.length < b.byteLength) throw new Error("Missing or truncated glTF buffer.");
    return data;
  });
  function bufferView(index) {
    const bv = json.bufferViews?.[index],
      buffer = buffers[bv?.buffer],
      start = bv?.byteOffset ?? 0;
    if (
      !buffer ||
      !Number.isSafeInteger(bv.byteLength) ||
      !Number.isSafeInteger(start) ||
      start < 0 ||
      bv.byteLength < 0 ||
      start + bv.byteLength > buffer.length
    )
      throw new Error("Invalid glTF buffer view.");
    if (bv.extensions?.EXT_meshopt_compression)
      throw new Error("Meshopt-compressed buffers are unsupported.");
    return buffer.subarray(start, start + bv.byteLength);
  }
  const cache = new Map();
  function accessor(index, shapes, count) {
    const a = json.accessors?.[index],
      spec = glTypes[a?.componentType];
    if (!spec || !shapes.includes(a.type)) throw new Error("Unsupported glTF accessor type.");
    if (!Number.isSafeInteger(a.count) || a.count < 1 || (count != null && a.count !== count))
      throw new Error("Invalid glTF accessor count.");
    if (cache.has(index)) return cache.get(index);
    const n = components[a.type],
      [size, get, max] = spec;
    function source(viewIndex, offset, stride, length, elements, bytes) {
      const buf = bufferView(viewIndex);
      if (
        !Number.isSafeInteger(offset) ||
        offset < 0 ||
        !Number.isSafeInteger(stride) ||
        stride < elements * bytes ||
        offset + (length - 1) * stride + elements * bytes > buf.length
      )
        throw new Error("Invalid glTF accessor bounds.");
      return new DataView(buf.buffer, buf.byteOffset + offset, buf.byteLength - offset);
    }
    function row(view, offset, data, output) {
      for (let c = 0; c < n; c++) {
        const v = view[get](offset + c * size, true);
        if (!Number.isFinite(v)) throw new Error("Non-finite glTF attribute.");
        data[output + c] = a.normalized ? Math.max(-1, v / max) : v;
      }
    }
    const stride = json.bufferViews?.[a.bufferView]?.byteStride ?? n * size;
    const base =
      a.bufferView == null ? null : source(a.bufferView, a.byteOffset ?? 0, stride, a.count, n, size);
    // Sparse-only accessors can expand far beyond the size of the uploaded file.
    if (!base && a.count * n > 16_777_216) throw new Error("glTF sparse accessor is too large.");
    const data = new Float64Array(n * a.count);
    if (base) for (let i = 0; i < a.count; i++) row(base, i * stride, data, i * n);
    if (a.sparse) {
      const { indices, values, count: length } = a.sparse;
      if (
        !Number.isSafeInteger(length) ||
        length < 1 ||
        length > a.count ||
        ![5121, 5123, 5125].includes(indices?.componentType) ||
        !values
      )
        throw new Error("Invalid glTF sparse accessor.");
      const [indexSize, indexGet] = glTypes[indices.componentType];
      const indicesView = source(
        indices.bufferView,
        indices.byteOffset ?? 0,
        indexSize,
        length,
        1,
        indexSize,
      );
      const valuesView = source(values.bufferView, values.byteOffset ?? 0, n * size, length, n, size);
      let previous = -1;
      for (let i = 0; i < length; i++) {
        const target = indicesView[indexGet](i * indexSize, true);
        if (target <= previous || target >= a.count) throw new Error("Invalid glTF sparse index.");
        row(valuesView, i * n * size, data, target * n);
        previous = target;
      }
    }
    const result = { data, n, count: a.count };
    cache.set(index, result);
    return result;
  }
  const textures = new Map();
  async function texture(info) {
    const tex = json.textures?.[info.index];
    const useWebp = Object.hasOwn(tex?.extensions || {}, "EXT_texture_webp");
    const source = useWebp ? tex.extensions.EXT_texture_webp?.source : tex?.source;
    const img = json.images?.[source];
    if (useWebp && (!Number.isSafeInteger(source) || source < 0 || !img))
      throw new Error("Invalid EXT_texture_webp image source.");
    if (!img || info.extensions?.KHR_texture_transform)
      throw new Error("Unsupported base-color texture encoding or transform.");
    if (useWebp && !img.uri && img.mimeType !== "image/webp")
      throw new Error("EXT_texture_webp bufferView requires image/webp.");
    if (!textures.has(source)) {
      const image = img.uri ? embedded(img.uri) : { bytes: bufferView(img.bufferView), mime: img.mimeType };
      const webp = sniffMime(image.bytes) === "image/webp";
      if (useWebp && !webp) throw new Error("EXT_texture_webp source must contain a WebP image.");
      textures.set(source, { pixels: await imagePixels(image.bytes, image.mime), webp });
    }
    const cached = textures.get(source);
    if (useWebp && !cached.webp) throw new Error("EXT_texture_webp source must contain a WebP image.");
    return { pixels: cached.pixels, sampler: json.samplers?.[tex.sampler] || {} };
  }
  const meshes = [],
    skins = new Map(),
    scene = sceneNodes(json);
  async function emit(index, nodeIndex) {
    const node = json.nodes?.[nodeIndex] ?? {};
    if (node.skin != null && !skins.has(node.skin)) {
      skins.set(node.skin, readSkin(json, node.skin, accessor, scene));
    }
    if (!json.meshes?.[index]) throw new Error("Missing glTF mesh.");
    for (const p of json.meshes[index].primitives) {
      const mode = p.mode ?? 4;
      if (![4, 5, 6].includes(mode))
        throw new Error(
          "Slice 3D requires triangles. For a point-cloud preview, supply the original Gaussian PLY.",
        );
      if (p.extensions?.KHR_draco_mesh_compression)
        throw new Error("Draco-compressed meshes are unsupported.");
      const pos = accessor(p.attributes.POSITION, ["VEC3"]);
      const targets = (p.targets || []).map((target) =>
        target.POSITION == null ? null : accessor(target.POSITION, ["VEC3"], pos.count).data,
      );
      const influences =
        node.skin == null
          ? null
          : skinInfluences(json, p.attributes, pos.count, skins.get(node.skin), accessor);
      if (p.indices != null) {
        const indexSpec = json.accessors?.[p.indices];
        if (!indexSpec || ![5121, 5123, 5125].includes(indexSpec.componentType) || indexSpec.normalized)
          throw new Error("glTF triangle indices must be unsigned integers.");
      }
      const idx = p.indices != null ? accessor(p.indices, ["SCALAR"]).data : null;
      if (idx?.some((v) => !Number.isInteger(v) || v < 0 || v >= pos.count))
        throw new Error("Invalid triangle index.");
      const length = idx?.length ?? pos.count;
      if (length < 3 || (mode === 4 && length % 3)) throw new Error("Incomplete triangle primitive.");
      const mat = json.materials?.[p.material] || {},
        pbr = mat.pbrMetallicRoughness || {},
        info = pbr.baseColorTexture;
      const factor = pbr.baseColorFactor ?? [1, 1, 1, 1];
      if (
        !Array.isArray(factor) ||
        factor.length !== 4 ||
        !factor.every((v) => Number.isFinite(v) && v >= 0 && v <= 1)
      )
        throw new Error("Invalid glTF base color factor.");
      if (mat.alphaMode != null && !["OPAQUE", "MASK", "BLEND"].includes(mat.alphaMode))
        throw new Error("Invalid glTF alpha mode.");
      const color =
        p.attributes.COLOR_0 == null ? null : accessor(p.attributes.COLOR_0, ["VEC3", "VEC4"], pos.count);
      const uv = info
        ? accessor(p.attributes["TEXCOORD_" + (info.texCoord ?? 0)], ["VEC2"], pos.count)
        : null;
      meshes.push({
        base: pos.data,
        targets,
        influences,
        nodeIndex,
        skin: node.skin,
        weights: node.weights ?? json.meshes[index].weights,
        material: {
          idx,
          mode,
          length,
          color,
          uv,
          factor,
          texture: info && (await texture(info)),
          alphaMode: mat.alphaMode || "OPAQUE",
          cutoff: mat.alphaCutoff ?? 0.5,
        },
      });
    }
  }
  if (json.nodes?.length) {
    for (const i of scene.active) {
      const node = json.nodes[i];
      if (node.mesh != null) await emit(node.mesh, i);
    }
  } else for (let i = 0; i < (json.meshes || []).length; i++) await emit(i);
  if (!meshes.length) throw new Error("No triangles in the selected glTF scene.");
  const sampler = prepareClip(json, accessor, clip, frames);
  const animation = sampler?.info ?? null;
  function pose(index) {
    if (!Number.isInteger(index) || index < 0 || index >= frames) throw new Error("Invalid frame index.");
    const overrides = sampler?.sample(animation.times[index]);
    const world = scene.worldMatrices(overrides),
      palettes = new Map();
    for (const [id, joints] of skins) palettes.set(id, skinMatrices(joints, world));
    return {
      kind: "mesh",
      meshes: meshes.map((mesh) => ({
        ...mesh.material,
        positions: posedPositions(
          mesh,
          world.get(mesh.nodeIndex),
          overrides?.get(mesh.nodeIndex)?.weights ?? mesh.weights,
          palettes.get(mesh.skin),
        ),
      })),
    };
  }
  return {
    pose,
    animation,
    count: frames,
    clip: animation?.clip ?? "",
    start: animation?.times[0] ?? 0,
    duration: animation?.duration ?? 0,
  };
}

const plyTypes = {
  char: glTypes[5120],
  int8: glTypes[5120],
  uchar: glTypes[5121],
  uint8: glTypes[5121],
  short: glTypes[5122],
  int16: glTypes[5122],
  ushort: glTypes[5123],
  uint16: glTypes[5123],
  int: [4, "getInt32"],
  int32: [4, "getInt32"],
  uint: glTypes[5125],
  uint32: glTypes[5125],
  float: glTypes[5126],
  float32: glTypes[5126],
  double: [8, "getFloat64"],
  float64: [8, "getFloat64"],
};

export function gaussianModel(bytes) {
  const head = decodeText(bytes.subarray(0, 65536)),
    end = /^end_header\r?\n/m.exec(head);
  if (!end) throw new Error("Missing PLY header terminator.");
  const header = head.slice(0, end.index + end[0].length),
    offset = new TextEncoder().encode(header).length;
  let format,
    count,
    stride = 0,
    element;
  const props = new Map();
  for (const line of header.trim().split(/\r?\n/)) {
    const [key, a, b, version] = line.trim().split(/\s+/);
    if (key === "format") {
      if (b !== "1.0" || !["ascii", "binary_little_endian"].includes(a))
        throw new Error("Supported Gaussian PLY formats are ASCII and binary little-endian 1.0.");
      format = a;
    }
    if (key === "element") {
      element = a;
      if (a !== "vertex" && Number(b) !== 0)
        throw new Error("Expected an uncompressed vertex-only Gaussian PLY.");
      if (a === "vertex") count = Number(b);
    }
    if (key === "property" && element === "vertex") {
      if (!plyTypes[a] || version || props.has(b))
        throw new Error("Unsupported Gaussian PLY property encoding.");
      props.set(b, { type: plyTypes[a], offset: stride, index: props.size });
      stride += plyTypes[a][0];
    }
  }
  const required = [
    "x",
    "y",
    "z",
    "opacity",
    "scale_0",
    "scale_1",
    "scale_2",
    "rot_0",
    "rot_1",
    "rot_2",
    "rot_3",
  ];
  const dc = ["f_dc_0", "f_dc_1", "f_dc_2"],
    rgb = ["red", "green", "blue"];
  const hasDC = dc.every((p) => props.has(p));
  if (!format || !required.every((p) => props.has(p)) || !(hasDC || rgb.every((p) => props.has(p))))
    throw new Error(
      "Expected Gaussian PLY positions, log scales, quaternion, opacity logit, and DC or RGB colors. Ordinary point clouds are unsupported.",
    );
  if (!hasDC && rgb.some((name) => props.get(name).type !== glTypes[5121]))
    throw new Error(
      "Gaussian RGB properties must be unsigned bytes, or supply floating-point DC coefficients.",
    );
  if (!Number.isSafeInteger(count) || count < 1) throw new Error("Invalid Gaussian PLY vertex count.");
  const rows = format === "ascii" ? decodeText(bytes.subarray(offset)).trim().split(/\r?\n/) : null;
  if (rows ? rows.length !== count : count * stride !== bytes.length - offset)
    throw new Error("Gaussian PLY payload does not match its declared vertex count.");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength),
    splats = [];
  for (let i = 0; i < count; i++) {
    const row = rows && rows[i].trim().split(/\s+/);
    if (row && row.length !== props.size) throw new Error("Invalid ASCII PLY vertex.");
    const read = (key) => {
      const p = props.get(key);
      const v = row ? Number(row[p.index]) : view[p.type[1]](offset + i * stride + p.offset, true);
      if (!Number.isFinite(v)) throw new Error("Non-finite Gaussian PLY attribute.");
      return v;
    };
    const center = ["x", "y", "z"].map(read),
      scales = ["scale_0", "scale_1", "scale_2"].map((p) => Math.exp(read(p)));
    const quaternion = ["rot_0", "rot_1", "rot_2", "rot_3"].map(read),
      norm = Math.hypot(...quaternion);
    if (!norm || !scales.every((s) => Number.isFinite(s) && s > 0))
      throw new Error("Invalid Gaussian scale or rotation.");
    const [w, x, y, z] = quaternion.map((v) => v / norm);
    const rotation = trs([0, 0, 0], [x, y, z, w], [1, 1, 1]);
    const extent = center.map((_, k) => 3 * Math.hypot(...scales.map((s, j) => rotation[j * 4 + k] * s)));
    const color = hasDC ? dc.map((p) => 255 * (0.5 + 0.2820947918 * read(p))) : rgb.map(read);
    splats.push({ center, scales, rotation, extent, color, alpha: 1 / (1 + Math.exp(-read("opacity"))) });
  }
  return { kind: "splat", splats };
}
