# Nanoodle Run Engine — server-side re-implementation spec

Blueprint = play.html RUNTIME_JS (the exported-app runtime). Line refs are play.html.

## Endpoints & auth
```
NANOGPT = https://nano-gpt.com
IMG_ENDPOINT   POST {NANOGPT}/v1/images/generations      (note: NOT /api/v1)
CHAT_ENDPOINT  POST {NANOGPT}/api/v1/chat/completions
VIDEO submit   POST {NANOGPT}/api/generate-video
VIDEO poll     GET  {NANOGPT}/api/video/status?requestId=<id>
AUDIO speech   POST {NANOGPT}/api/v1/audio/speech        (music + tts + remix)
AUDIO poll     GET  {NANOGPT}/api/tts/status?<qs>
TRANSCRIBE     POST {NANOGPT}/api/v1/audio/transcriptions   (multipart)
Catalogs (public, no key): /api/v1/models?detailed=true, /api/v1/image-models,
                           /api/v1/video-models, /api/v1/audio-models
```
Every JSON call: `Content-Type: application/json` + BOTH `Authorization: Bearer <key>` and `x-api-key: <key>`.
Multipart transcribe: the two auth headers, NO explicit Content-Type (let the http lib set boundary). File form field MUST be named "file"; also fields `model`, optional `language`.

All media is inlined as base64 `data:` URLs in JSON bodies (no upload endpoint). MEDIA_INLINE_MAX = 4.4MB — guard locally and raise a clear error above it. Chat runs NON-STREAMING (no `stream` key); parse `r.json()` once.

Model strings pass through VERBATIM (`body.model = node.fields.model`). Missing model → error "pick a model first". Endpoint choice is by node TYPE, never by model lookup. The catalog is optional/best-effort (capability gating + clamps); the library must run fine with no catalog fetch.

## Per-node payloads

### llm → CHAT_ENDPOINT (genChat 1481-1504, run 2574-2603)
```
body = { model, messages, temperature: 0.8 }
if maxTokens          body.max_tokens = +maxTokens
if format == "JSON"   body.response_format = { type: "json_object" }
if reasoningEffort set and != "default"  body.reasoning_effort = value
```
messages: optional {role:"system", content: fields.system} then user message.
User content = plain string prompt, UNLESS wired images (img1,img2,... sorted by index) or wired audio:
then array `[{type:"text",text:prompt}, {type:"image_url",image_url:{url:<value verbatim>}}..., audioPart?]`.
audioPart = `{type:"input_audio", input_audio:{data:<base64 body, no data: prefix>, format:"mp3"|"wav"|...}}`.
prompt = wired `prompt` port value ?? fields.prompt; error "no prompt" if empty.
Parse: `j.choices[0].message.content` (if array, join `.map(p=>p.text)`); throw "no text in response" if null/empty.
(withLocale non-English system suffix: SKIP in the library / make opt-in.)

### vision → same as llm: one user message [{text: q||"Describe this image."}, {image_url: inp.image}]

### image / edit / inpaint → IMG_ENDPOINT (genImage 1465-1480)
```
body = { model, size: fields.size || "1024x1024", n: variations||1, response_format: "b64_json" }
if prompt        body.prompt = prompt
if source image  body.imageDataUrl = <string OR array of strings (edit multi-ref)>
if mask          body.maskDataUrl = <mask data URL; white = repaint>
+ seed (when numeric), + customCivitaiAir (model "custom-civitai"), + LoRA params
```
- image node: `variations` → n (multi output = j.data list).
- edit: sources from wired `image, image2, ...` ports; single → string, multiple → array. Prompt may be empty for upscaler models — do not hard-require.
- edit role models (`IMG_INPUT_ROLES`, nodes.mjs): a few models need a fixed ORDERED set of images — `flux-pro/v1/vto` = `[person, garment]`. The catalog declares no minimum (215-model scan 2026-07-31), so refuse before the send when a slot is unwired, reading the RAW port keys (port collection compacts, so an empty slot 1 would silently promote slot 2's image into the person role — a paid wrong result). Sending 1 image is a plain 400, uncharged; reversed order is charged and drifts identity toward the garment photo.
- edit/inpaint returns: request `multi` and keep `urls[0]`, warning `model returned N images, kept the first` — always-N models (`fixed_image_count: 4`: `midjourney/text-to-image`, `higgsfield-soul`) bill for the whole batch. No probed model dishonors `n: 1`.
- Trap: a data-URL whose MIME doesn't match its bytes comes back as a 413 `IMAGE_INPUT_TOO_LARGE` with nonsense dimensions, not a format error.
- Upstream-broken, not client-fixable (2026-07-31): `riverflow-2-fast` / `riverflow-2-standard` 400 "invalid AIR identifier" (use `riverflow-2.0-pro`); `gpt-image-1-mini`, `cogview-4`, `lucid-origin`, `reve-text-to-image`, `imagen-3.0-generate-002` fail fast, uncharged, with or without `size`.
- inpaint: source+mask from ports or fields. Before send, composite the mask onto opaque black at the **source image's** exact pixel size (`maskToSource` — same as play.html / index.html canvas path) so `maskDataUrl` dimensions always match.
Parse: `j.data[]` → `d.b64_json ? "data:<sniffed mime>;base64,"+b64 : d.url`. Sniff mime from magic bytes (PNG \x89PNG, JPEG \xFF\xD8, GIF, WEBP RIFF....WEBP; default image/png). Throw "no image in response" if empty.

### tvideo / ivideo / vedit / lipsync → submit + poll (genVideo 1527-1588)
```
body = { model, prompt }
+ dims from node fields: aspect → aspect_ratio, duration → duration, resolution → resolution
  (catalog can rename e.g. aspect→orientation / duration→seconds; WITHOUT catalog use the standard names)
+ ivideo/lipsync source image → body.imageDataUrl (data: or https, verbatim)
  (lipsync: a preset-only avatar — catalog row with image_to_video false, e.g. heygen/avatar-v —
   needs no portrait and never sends one; catalog miss keeps the portrait requirement)
+ ivideo wired endframe → body.last_image
+ vedit source: https URL → body.videoUrl ; local data → body.videoDataUrl
+ lipsync audio: https → body.audioUrl ; local → body.audioDataUrl
+ Object.assign(body, fields.modelOpts || {})   (per-model knobs incl. seed)
+ tvideo wired ref1.. → body.reference_images (array) — catalog may rename key; default "reference_images"
```
Submit response: `runId = j.runId || j.id`. Then poll every 5s: GET /api/video/status?requestId=<runId>.
status = (s.data?.status || s.status).toUpperCase().
COMPLETED|SUCCEEDED → url = s.data?.output?.video?.url || out.url || out.video?.[0]?.url (out = s.data?.output or s).
FAILED|ERROR|CANCELED → raise "video failed: " + (s.data?.error || status). Timeout 600s.

### music / tts / remix → AUDIO speech endpoint (genAudio 1591-1637)
```
body = { model, input: <wired text ?? fields.prompt> } + params
music params: lyrics, instrumental(bool), duration(number), negative_prompt, seed, response_format(default "mp3")
tts params:   voice, speed(omit when 1), instructions, response_format(default "mp3")
remix params: lyrics, duration, response_format + body.audio = <source: https as-is | local data URL>
+ merge fields.extraJson (parsed object) verbatim last
Omit empty params. (Catalog gating of voice/duration: skip in v1 — send what the node has.)
```
Response handling:
- content-type JSON → url = j.url||j.audioUrl||j.data?.url||j.data?.audioUrl; if none but j.runId||j.id → poll
  GET /api/tts/status?runId=..&model=..&cost=..&paymentSource=..&isApiRequest=true every 3s;
  status lowercase: completed|succeeded → s.audioUrl||s.url||s.data?.audioUrl||s.data?.url;
  error|failed|content_policy_violation → raise. Timeout 300s.
- else BINARY body → the audio bytes; mime from response content-type (pin from requested format if generic).
  Library returns bytes+mime (a data: URL or MediaRef), not an object URL.

### transcribe → multipart (1641-1666)
FormData: file=<audio blob> (field name "file"), model, language?. Local guard: >3.5MB raise.
Parse: `j.transcription ?? j.text ?? j.data?.transcription ?? j.data?.text`.

## Cost extraction (costFromJson 998-1013)
USD priority: j.cost (if >0) → j.x_nanogpt_pricing.(costUsd|cost|amount) → j.metadata?.cost → header x-cost / x-nano-cost.
Balance: header x-remaining-balance (wins) → j.remainingBalance → x_nanogpt_pricing.remainingBalance.
Present-but-zero = known-included (subscription), keep 0. Absent → cost unknown (mark total inexact).

## HTTP errors (922-935)
- A 403 with the Vercel challenge header or the Vercel Security Checkpoint page → `blocked` error.
- Other 401/403 responses → auth error ("API key rejected").
- 402 OR body matching /insufficient|balance|funds|not enough|payment required/i → out-of-funds error.
- else → error "<status>: <body first 160 chars>".
No streaming retries needed (engine is non-streaming). Poll GET failures: silently continue the loop until timeout.

## Execution (runGraph 3000-3133)
1. Alias/filter nodes (materialize): audio→tts, drop unknown types + orphaned links, migrate music/tts inbound "text" port → "prompt".
2. Kahn topological order; cyclic → error naming the cyclic nodes.
3. Concurrency: node starts when ITS deps finish (siblings run concurrently). Library: same semantics (asyncio / Promise per node).
4. Input resolution per node: for declared ports, value = srcNode.out[from.port]. Dynamic families: img\d+ / image\d*, vid\d+, clip\d+, audio, endframe, ref\d+, frame\d+ (vframes outputs). ANY other inbound link = FIELD OVERRIDE: run with fields = {...fields, [port]: value} (that's how wired prompt/system/lyrics/q override typed values).
5. Node failure: record error for that node, continue independent lanes (library default: collect; raise at end if a sink failed — see DESIGN).
6. comment nodes never run. Fixed-seed skip-cache: optional for a library (stateless one-shot runs don't need it) — SKIP in v1.

## Local nodes to IMPLEMENT (pure logic)
- text: out.text = fields.text
- upload/aupload/vupload: out = the stored/provided data URL
- choice: options = fields.options.split("\n") non-empty trimmed; out = fields.selected if in options else first; error if no options
- join: [a,b].filter(non-empty).join(sep) where sep = fields.sep ?? " ", literal "\\n" in sep means newline
- comment: skip

## Local media nodes (on-device; pure-JS first, ffmpeg fallback)
Implemented in `src/local-media.mjs` + `src/mp4cat.mjs` (JS) / `nanoodle/local_media.py` (Py). Behaviour mirrors the browser (play.html / index.html):

**Pure-JS path (no ffmpeg)** — same algorithms the app uses when it can avoid re-encode:
- **combine** — matching mp4s → lossless `MP4CAT` remux (browser primary path; `dedup` ignored on remux).
- **trim** — PCM WAV → slice + `encodeWavMono` mono @ target rate.
- **resize** — PNG via pure decode/scale/encode (canvas-equivalent `resizePlan` geometry).

**ffmpeg/ffprobe on PATH (soft dependency, not an npm package)** — when pure JS can't handle the format:
- mismatched / non-mp4 **combine**, JPEG **resize**, **vframes**, **soundtrack**, non-WAV **trim**, **extractaudio**.

Node behaviour:
- **resize** — `mode` fit|fill|exact, width/height; fit never upscales; PNG stays PNG else JPEG.
- **vframes** — `frames` 1–12, `gap` seconds, `dir` end|start; emits `frame1..frameN` JPEG data URLs.
  - **wiredFramesFloor**: before run, `fields.frames` is raised to the highest wired outbound `frameK` port (same as play.html). Prevents starving a `frame3` consumer when a saved graph still has `frames:1` after paid upstream steps. Settings UI also floors the knob to that value.
- **combine** — clip1../vid1.. inputs (≥2), ordered by port number across both families; remux when params match, else re-encode; `dedup` only on re-encode path.
- **soundtrack** — video+audio; `loop` loops audio to fill video length; mux → mp4.
- **trim** — audio → mono WAV @ 16 kHz; `start` + `length` (default 30s when blank).
- **extractaudio** — video → mono WAV @ 16 kHz; blank `length` = whole clip after start.

**Executor plumbing:**
- `run({ timeoutMs, signal })` aborts in-flight ffmpeg (SIGKILL) and fails the run; local media nodes check the signal between frames/clips.
- Custom `fetch` from `Workflow` opts is passed into local media (https CDN inputs).
- `MEDIA_INLINE_MAX` (~4.4 MB) is enforced on user media **inputs only when the graph has network nodes**. Local-only graphs may accept larger data: URLs; network send sites still refuse oversized bodies.

Missing ffmpeg when the pure path cannot cover the op → clear error naming the binary. No `UnsupportedNodeError` for these types.
