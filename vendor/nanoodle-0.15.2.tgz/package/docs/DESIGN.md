# nanoodle executor libraries — DESIGN (binding decisions)

The executor repositories use the MIT license. Their package manifests specify supported runtimes and media dependencies.
- /home/ntc/dev/nanoodlecom/nanoodle-js  — npm package `nanoodle` (ESM, built-in fetch, node:test)
- /home/ntc/dev/nanoodlecom/nanoodle-py  — PyPI package `nanoodle` (stdlib urllib, unittest)

Read SPEC-format.md, SPEC-engine.md, SPEC-io.md in this directory first. They are the contract.

## Public API — JS
```js
import { Workflow, NanoodleError, UnsupportedNodeError, RunError } from "nanoodle";

const wf = await Workflow.load("noodle-graph.json", { apiKey });   // path, or pass a parsed object / JSON string to Workflow.fromJSON(objOrString, opts)
wf.inputs    // [{ key, nodeId, field, kind, label, optional, def, options? }]  key = resolved friendly name
wf.outputs   // [{ key, nodeId, type, ports }]
wf.settings  // [{ key, nodeId, field, kind, def, options? }]

const result = await wf.run({ "Text": "a cozy ramen shop" }, { settings: { "n3.model": "..." }, timeoutMs, signal, onProgress });
result.get("Image")          // primary output value of that sink node
result.outputs               // { [key]: value } (plus node-id keys)
result.costUsd, result.costExact, result.remainingBalance
result.nodes                 // per-node { status: done|error|gated|skipped, out, error, costUsd, ms } (+ gate / gatedBy)
result.errors                // [] of { nodeId, name, message }
result.gated                 // [] of { nodeId, name, message, yes, skipped: [nodeId] } — closed Decide gates
```
- A ⚖️ Decide yes/no gate that answers no is NOT a failure: that node is "gated" (it ran and billed; out = { text: "no", decision }), every node downstream of it is "skipped" with gatedBy = the gate's id (never ran, never billed), result.errors is untouched and run() resolves. A node fed by a closed gate AND a real failure is an error ("upstream failed").
- run() REJECTS with RunError when any SINK node failed (RunError carries .result with partials). Non-sink failure that no sink depends on → warning in result.errors only. (A failed non-sink makes its downstream sinks fail with "upstream failed: <name>" — so effectively any failure that matters rejects.)
- Media values: class MediaRef { url (data: or https), mime?, async bytes(), async save(path), toString() → url }. Text outputs are plain strings. Inputs accept: string (text), data: URL, https URL, Buffer/Uint8Array (+ mime option via {data, mime}), or local file path via Workflow helpers (mediaFromFile(path)).
- onProgress(evt): { type: "node-start"|"node-done"|"node-error"|"node-gated"|"node-skipped"|"poll", nodeId, name, ... }.
- Constructor opts: { apiKey = process.env.NANOGPT_API_KEY, baseUrl = "https://nano-gpt.com", fetch = globalThis.fetch, pollIntervals, timeouts, catalog } — injectable fetch/baseUrl is what the test harness uses.

CLI (bin/nanoodle.mjs, "nanoodle" bin entry):
```
nanoodle run graph.json --input Text="a cozy ramen shop" --input n2.system=@file.txt --set n3.size=1k --out ./out [--json]
nanoodle inspect graph.json      # prints inputs/outputs/settings + node table
nanoodle init [path]             # scaffolds the starter graph (default ./noodle-graph.json)
```
Media outputs are saved under --out (default ./noodle-out, created only when needed; fetch https, decode data:).
The JSON run summary is ALWAYS printed to stdout; progress/log lines go to stderr; --json is quiet mode
(suppresses the stderr lines). Exit 0 success / 1 failure. This run contract is shared with nanoodle-py.

## Public API — Python (mirror, pythonic)
```python
from nanoodle import Workflow, NanoodleError, UnsupportedNodeError, RunError, media_from_file

wf = Workflow.load("noodle-graph.json", api_key=None)   # env NANOGPT_API_KEY fallback; Workflow.from_dict(d) too
wf.inputs / wf.outputs / wf.settings                     # lists of dataclasses, same fields as JS
result = wf.run({"Text": "a cozy ramen shop"}, settings=None, timeout=None, on_progress=None)
result["Image"]              # __getitem__ = outputs lookup (friendly key or node id)
result.outputs, result.cost_usd, result.cost_exact, result.remaining_balance, result.nodes, result.errors, result.gated
```
- Gates: NodeRun.status "gated" (+ .gate {yes, message}) / "skipped" (+ .gated_by); result.gated [{node_id, name, message, yes, skipped}]; result[key] for a gated-off output raises GatedOutputError (a KeyError).
- Sync API (urllib + concurrent.futures ThreadPoolExecutor for node concurrency). Same RunError semantics.
- MediaRef: .url, .mime, .bytes(), .save(path), __str__ → url.
- Injectable transport: Workflow(..., base_url=..., http=callable) for the harness (default small urllib wrapper).
- CLI: `python -m nanoodle run|inspect ...` mirroring the JS flags.

## Shared behaviors (both)
- run() input validation UPFRONT: unknown input key → error listing valid keys; missing required input with empty field default → error naming it; no API key while graph has network nodes → error BEFORE any node runs.
- Unknown node types that must RUN → UnsupportedNodeError at run start (fail fast, before spending), naming node + type. Workflow.load only warns.
- Local media ops (resize/vframes/combine/soundtrack/trim/extractaudio): pure-JS first (MP4CAT remux, PCM-WAV trim, PNG resize — same as the browser), then ffmpeg on PATH as the heavy fallback (soft dependency; not an npm package). Clear error if ffmpeg is required and missing. `timeoutMs`/`signal` kill ffmpeg; custom `fetch` is honoured. vframes raises `frames` to the highest wired `frameK` (wiredFramesFloor).
- No locale suffix, no catalog fetch, no seed skip-cache, no telemetry/analytics of ANY kind. Never log the API key. Media over 4.4MB inline → clear local error when the graph has network nodes (or at send time); local-only graphs may load larger files.
- Version: 0.5.0.

## Replacing the browser executor (roadmap)

The nanoodle.com app still runs graphs with a custom inlined processor:

| Surface | Role today |
|---|---|
| `index.html` | Editor run loop (groups, seed reuse, demo, DOM) |
| `play.html` `RUNTIME_JS` / `NoodleApp` | Play + **exported apps** (SPEC blueprint) |
| `nanoodle-js` | Headless reimplementation of that blueprint (Node CLI + library) |

Long-term goal: **one engine** — browser UI shells call into `nanoodle-js` (or a browser build of it); play export ships the same code. Do **not** big-bang replace; land capability in the library first, then dual-run, then swap surfaces.

### Phases

| Phase | Goal | Status |
|---|---|---|
| **0** | Local media pure-JS path matching the browser (MP4CAT / PCM-WAV / PNG); ffmpeg soft fallback | Done (v0.3) |
| **A** | Browser-ready **core surface**: no top-level `node:fs` in media; env-safe Workflow; `nanoodle/browser` export | Done (v0.3) |
| **B** | **Payload parity harness**: same fixtures through play `RUNTIME_JS` and `Workflow.run` → identical NanoGPT bodies | Done (13 scenarios, literal compare — nanoodle `scripts/check-js-parity.mjs`) |
| **C** | Close remaining fidelity gaps (inpaint mask composite onto black @ source size; `run({}, { defaults: false })` = play's fields-authoritative contract) | Done (v0.3–0.4) |
| **D** | Split local-media so pure paths need no `node:child_process` / hard zlib at import time (env-adaptive zlib.mjs; PNG codec + share decode async & Buffer-free) | Done (v0.4) |
| **E** | play export / `NoodleApp.runGraph` delegates network runs to the package (UI + orchestration stay in play; **default ON** — opt out with `?engine=play` / `njs_engine="0"`, force with `?engine=js`; bundle via nanoodle `scripts/gen-js-engine.mjs`). Per-run vetoes mirror the editor's (see Phase G) | Landed (default ON as of 2026-07-16) |
| **F** | Editor `runGroup` delegates network runs to the package, same seam as play (UI + orchestration — groups, seed cache, retry reuse, poison-propagate, pending-job resume, demo — stay in index.html; **default ON** — opt out with `?engine=play` / `njs_engine="0"`, force with `?engine=js`). The editor lazy-loads `vendor/njs-engine.js` (emitted by nanoodle `scripts/gen-js-engine.mjs` alongside the play block) only when the flag is on, so the landing page carries none of its weight. Parity proof: nanoodle `scripts/check-njs-editor-delegation.mjs` | Landed (default ON as of 2026-07-16) |
| **G** | Close the library fidelity gaps so every network type delegates on every surface, then retire the dual network runners (or keep the built-ins as the `?engine=play` escape hatch only). Landed: video ref key + cap resolution (`modelRefSpec`, tvideo + vedit), lipsync charged-aware trim-retry ladder (`ctx.trimAudio` browser hook), shim-side `blob:` → `data:` materialization. Remaining per-run vetoes, by design: image `variations>1` (this package stays permissive on a catalog miss — its documented contract and play's behavior — while the editor clamps to 1, so multi-variation runs stay built-in on both surfaces); wired tvideo/vedit refs in the **editor only** (editor is permissive-OFF on a catalog miss where this package and play are permissive-ON); pending jobs owned by the other engine. Dropping the built-in runners needs those asymmetries unified first | In progress (2026-07-16: all types delegate; dual runners still shipped) |

### Browser entry (Phase A)

```js
import { Workflow, NanoClient, materialize, deriveInputs } from "nanoodle/browser";

const wf = Workflow.fromJSON(graphObj, { apiKey, fetch, payment });
await wf.run({ Text: "hi" });
```

- `media.mjs` base64/data-URL helpers work without `Buffer` (uses `btoa`/`atob` when needed).
- `MediaRef.save` / `mediaFromFile` / `Workflow.load(path)` dynamic-import `node:fs` (Node only).
- Phase D: `local-media.mjs` / `share.mjs` no longer top-level-import Node builtins. zlib goes through env-adaptive `zlib.mjs` (node:zlib in Node, Compression/DecompressionStream in the browser) — so the PNG codec and `decodeShareFragment` are **async** as of v0.4. Only the ffmpeg fallback dynamic-imports `node:child_process`/fs when it actually runs; in the browser those graphs use the pure paths or fail with the clear ffmpeg error.
- App shell (auth, DOM results, demo, seed skip-cache) stays in play/index until E/F.

## Repo layout (each)
README.md (quickstart: download the save from https://nanoodle.com → 3-line usage; the starter-graph example; supported node matrix; cost note; link to nanoodle app)
LICENSE (MIT, "Copyright (c) 2026 nanoodle contributors")
src/... (js: src/*.mjs re-exported from src/index.mjs; py: src/nanoodle/*.py)
tests/ (harness + unit tests; node:test / unittest — NO third-party test deps)
tests/fixtures/*.json (starter graph copy + purpose-built graphs: join/choice chain, llm-vision, edit multi-image, video poll, tts binary, music async-poll, transcribe, unsupported-node, cycle, field-override, duplicate-names, unknown-key errors)
tests/harness/ mock NanoGPT server (js: node:http; py: http.server in a thread) — canned per-endpoint responses, records every request (method/path/headers/body) for payload assertions, scriptable sequences (video pending→pending→completed; audio runId→poll; 401/402 errors; binary audio response with x-cost header).
scripts/live-spot-check.{mjs,py} — OPT-IN live test: reads NANOGPT_API_KEY from env or --env-file, runs fixture text→llm (model zai-org/glm-5.2, maxTokens 60) and prints text + cost; --image flag additionally runs the starter graph image step. NEVER run by CI.
.github/workflows/test.yml — offline unit tests only, on push.
.gitignore (node_modules, dist, __pycache__, .env, out/)

## Test plan (harness-first; the workflow phase will extend it)
Cover at minimum: graph load/aliases/link-migration/unknown-type; topo order + cycle error; concurrency (two parallel lanes both hit server); wiring incl. field override via textarea port; input derivation + all key-resolution orders + ambiguity errors + bare-scalar single-input; settings override + wired-field-refused; every network node type's payload EXACTLY (assert recorded body against spec) + response parse incl. b64 mime sniff, video poll loop + failure + timeout, audio JSON-url/JSON-runId-poll/binary branches, transcribe multipart (assert field name "file"); cost extraction priority incl. zero-cost-kept and header fallback; 401/402/500 error mapping; RunError partial results; MediaRef bytes/save; unsupported node fail-fast BEFORE any network call; no Authorization header leak in errors/repr.
